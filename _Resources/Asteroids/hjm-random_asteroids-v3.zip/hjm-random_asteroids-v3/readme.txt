144 rocks and asteroids in 12 rotated isometric views each.



Created by Hj. Malthaner, released as CC-By-3.0

http://opengameart.org/users/varkalandar



License details:
https://creativecommons.org/licenses/by/3.0/deed.en
